package com.example.cma.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.cma.Entity.Stock;

import jakarta.transaction.Transactional;

@Repository
@Transactional
public interface StockRepository extends JpaRepository<Stock,Long>{
	@Modifying
	@Query(value="delete from Stock where company_id_fk= :companyCode")
	public void deleteStockData(long companyCode);

}
