package com.example.LoginApplication.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.example.LoginApplication.entity.UserInfo;
import com.example.LoginApplication.exceptions.UserNotFoundException;
import com.example.LoginApplication.repository.UserInfoRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.Optional;

@ContextConfiguration(classes = {UserService.class})
@ExtendWith(SpringExtension.class)
class UserServiceTest {
    @MockBean
    private JwtService jwtService;

    @MockBean
    private PasswordEncoder passwordEncoder;

    @MockBean
    private UserInfoRepository userInfoRepository;

    @Autowired
    private UserService userService;

    /**
     * Method under test: {@link UserService#addUser(UserInfo)}
     */
    @Test
    void testAddUser() {
        UserInfo userInfo = new UserInfo();
        userInfo.setEmail("sowmya@gmail.com");
        userInfo.setName("Sowmya");
        userInfo.setPassword("sowmya@pass");
        userInfo.setRoles("USER");
        when(userInfoRepository.save(Mockito.<UserInfo>any())).thenReturn(userInfo);
        when(passwordEncoder.encode(Mockito.<CharSequence>any())).thenReturn("secret");

        UserInfo userInfo2 = new UserInfo();
        userInfo2.setEmail("Rakesh@gmail.com");
        userInfo2.setName("Rakesh");
        userInfo2.setPassword("rak@pass");
        userInfo2.setRoles("USER");
        assertEquals("user added to system ", userService.addUser(userInfo2));
        verify(userInfoRepository).save(Mockito.<UserInfo>any());
        verify(passwordEncoder).encode(Mockito.<CharSequence>any());
        assertEquals("secret", userInfo2.getPassword());
    }

    @Test
    void getuserbyidTestCase() throws UserNotFoundException {
        UserInfo u = new UserInfo("sadhana@gmail.com", "sadhana", "m", "sadhana123");
        userInfoRepository.save(u);
        when(userInfoRepository.findById("sadhana@gmail.com")).thenReturn(Optional.of(u));
        assertEquals(u, userService.findById("sadhana@gmail.com"));
    }
}

