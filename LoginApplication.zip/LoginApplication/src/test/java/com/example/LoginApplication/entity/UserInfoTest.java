package com.example.LoginApplication.entity;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class UserInfoTest {

    @Test
    void testConstructor() {
        UserInfo actualUserInfo = new UserInfo();
        actualUserInfo.setEmail("nehaayinala@gmail.com");
        actualUserInfo.setName("Neha");
        actualUserInfo.setPassword("nehaneha");
        actualUserInfo.setRoles("USER");
        String actualToStringResult = actualUserInfo.toString();
        String actualEmail = actualUserInfo.getEmail();
        String actualName = actualUserInfo.getName();
        String actualPassword = actualUserInfo.getPassword();
        assertEquals("nehaayinala@gmail.com", actualEmail);
        assertEquals("Neha", actualName);
        assertEquals("nehaneha", actualPassword);
        assertEquals("USER", actualUserInfo.getRoles());
        assertEquals("UserInfo(name=Neha, email=nehaayinala@gmail.com, password=nehaneha, roles=USER)",
                actualToStringResult);
    }
}

