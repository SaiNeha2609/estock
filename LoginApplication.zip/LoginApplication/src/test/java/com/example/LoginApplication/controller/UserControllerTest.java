package com.example.LoginApplication.controller;

import static org.mockito.Mockito.when;

import com.example.LoginApplication.dto.UserRequest;
import com.example.LoginApplication.entity.UserInfo;
import com.example.LoginApplication.service.JwtService;
import com.example.LoginApplication.service.UserService;
import static org.junit.jupiter.api.Assertions.assertEquals;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

@ContextConfiguration(classes = {UserController.class})
@ExtendWith(SpringExtension.class)
class UserControllerTest {
    @MockBean
    private AuthenticationManager authenticationManager;

    @MockBean
    private JwtService jwtService;

    @Autowired
    private UserController userController;

    @MockBean
    private UserService userService;

    /**
     * Method under test: {@link UserController#addNewUser(UserRequest)}
     */
    @Test
    void testAddNewUser() throws Exception {
        when(userService.addUser(Mockito.<UserInfo>any())).thenReturn("Add User");

        UserRequest userRequest = new UserRequest();
        userRequest.setEmail("Sowmya@gmail.com");
        userRequest.setName("Sowmya");
        userRequest.setPassword("sowmya@pass");
        String content = (new ObjectMapper()).writeValueAsString(userRequest);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post("/api/v1.0/user/add")
                .contentType(MediaType.APPLICATION_JSON)
                .content(content);
        MockMvcBuilders.standaloneSetup(userController)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().contentType("text/plain;charset=ISO-8859-1"))
                .andExpect(MockMvcResultMatchers.content().string("Add User"));
    }


    @Test
    public void testGetByEmail() {
        UserInfo userinfo=new UserInfo();
       userinfo.setName("vaishu");
       userinfo.setEmail("vaishu@gmail.com");
       userinfo.setPassword("vaishu@pass");
       userinfo.setRoles("USER");


        assertEquals("vaishu@gmail.com", userinfo.getEmail());

    }

    // Add more test cases for service or controller methods that use the Company class
}

