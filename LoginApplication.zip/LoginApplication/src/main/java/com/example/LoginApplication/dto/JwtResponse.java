package com.example.LoginApplication.dto;

public class JwtResponse {
}
