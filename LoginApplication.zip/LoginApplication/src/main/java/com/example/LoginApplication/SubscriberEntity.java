package com.example.LoginApplication;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class SubscriberEntity {

    @KafkaListener(topics="Day9", groupId="mygroup")
    public void consumeFromTopic(String message)
    {
        System.out.println("Consumer message is:  "+ message);
    }


}
